using UnityEngine;

public class PlanetControl : MonoBehaviour
{
    public GameObject sun;
    public GameObject earth;
    public GameObject moon;

    private SunRotation sunRotation;
    private EarthOrbit earthOrbit;
    private MoonOrbit moonOrbit;

    void Start()
    {
        // Get the rotation and orbit components
        sunRotation = sun.GetComponent<SunRotation>();
        earthOrbit = earth.GetComponent<EarthOrbit>();
        moonOrbit = moon.GetComponent<MoonOrbit>();
    }

    void Update()
    {
        // Control the Sun's rotation speed with 'Q' and 'E'
        if (Input.GetKey(KeyCode.Q))
        {
            sunRotation.rotationSpeed += 10f * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.E))
        {
            sunRotation.rotationSpeed = Mathf.Max(0, sunRotation.rotationSpeed - 10f * Time.deltaTime);
        }

        // Control Earth's orbit speed with 'W' and 'S'
        if (Input.GetKey(KeyCode.W))
        {
            earthOrbit.orbitSpeed += 10f * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.S))
        {
            earthOrbit.orbitSpeed = Mathf.Max(0, earthOrbit.orbitSpeed - 10f * Time.deltaTime);
        }

        // Control Earth's rotation speed with 'A' and 'D'
        if (Input.GetKey(KeyCode.A))
        {
            earthOrbit.rotationSpeed += 10f * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.D))
        {
            earthOrbit.rotationSpeed = Mathf.Max(0, earthOrbit.rotationSpeed - 10f * Time.deltaTime);
        }

        // Control Moon's orbit speed with 'Z' and 'X'
        if (Input.GetKey(KeyCode.Z))
        {
            moonOrbit.orbitSpeed += 10f * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.X))
        {
            moonOrbit.orbitSpeed = Mathf.Max(0, moonOrbit.orbitSpeed - 10f * Time.deltaTime);
        }

        // Control Moon's rotation speed with 'C' and 'V'
        if (Input.GetKey(KeyCode.C))
        {
            moonOrbit.rotationSpeed += 10f * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.V))
        {
            moonOrbit.rotationSpeed = Mathf.Max(0, moonOrbit.rotationSpeed - 10f * Time.deltaTime);
        }

        // Stop all movement with 'Spacebar'
        if (Input.GetKeyDown(KeyCode.Space))
        {
            ToggleMovement();
        }

        // Log the current speeds for the Sun, Earth, and Moon
        UnityEngine.Debug.Log($"Sun Rotation Speed: {sunRotation.rotationSpeed}");
        UnityEngine.Debug.Log($"Earth Orbit Speed: {earthOrbit.orbitSpeed}, Earth Rotation Speed: {earthOrbit.rotationSpeed}");
        UnityEngine.Debug.Log($"Moon Orbit Speed: {moonOrbit.orbitSpeed}, Moon Rotation Speed: {moonOrbit.rotationSpeed}");
    }

    private void ToggleMovement()
    {
        // Enable or disable all rotation and orbit scripts
        bool isActive = sunRotation.enabled = !sunRotation.enabled;
        earthOrbit.enabled = isActive;
        moonOrbit.enabled = isActive;

        string state = isActive ? "started" : "stopped";
        UnityEngine.Debug.Log($"All movements {state}.");
    }
}
