using UnityEngine;

public class BillboardScript : MonoBehaviour
{
    private Camera activeCamera;

    void LateUpdate()
    {
        // Find the currently active camera every frame
        activeCamera = Camera.main;  // Camera.main refers to the active camera tagged as "MainCamera"

        if (activeCamera != null)
        {
            // Make the quad face the active camera
            transform.LookAt(transform.position + activeCamera.transform.rotation * Vector3.forward,
                             activeCamera.transform.rotation * Vector3.up);
        }
    }
}
