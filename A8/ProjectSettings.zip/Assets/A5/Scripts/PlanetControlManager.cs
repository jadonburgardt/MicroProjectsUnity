using UnityEngine;

public class PlanetControlManager : MonoBehaviour
{
    private float defaultTimeScale = 1f;

    public void StartMovement()
    {
        // Resume the game by setting time scale to 1 (or default if needed)
        Time.timeScale = defaultTimeScale;
        Debug.Log("Game Resumed");
    }

    public void StopMovement()
    {
        // Pause the game by setting time scale to 0
        Time.timeScale = 0f;
        Debug.Log("Game Paused");
    }
}
