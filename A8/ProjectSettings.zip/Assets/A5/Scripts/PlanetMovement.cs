using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlanetMovement : MonoBehaviour
{
    public float rotationSpeed = 10f;
    public float orbitSpeed = 5f;
    private bool canMove = true;

    void Update()
    {
        if (canMove)
        {
            Rotate();
            Orbit();
        }
    }

    public void SetMovement(bool state)
    {
        canMove = state;
    }

    private void Rotate()
    {
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
    }

    private void Orbit()
    {
        transform.RotateAround(Vector3.zero, Vector3.up, orbitSpeed * Time.deltaTime);
    }
}
