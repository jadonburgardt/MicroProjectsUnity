using UnityEngine;

public class CameraManager : MonoBehaviour
{
    public Camera earthCam;
    public Camera sunCam;
    public Camera moonCam;
    public Camera defaultCam;

    private void Start()
    {
        // Ensure only the default camera is enabled initially
        SetActiveCamera(defaultCam);
    }

    public void ShowEarthView()
    {
        SetActiveCamera(earthCam);
        Debug.Log("Switched to EarthCam");
    }

    public void ShowSunView()
    {
        SetActiveCamera(sunCam);
        Debug.Log("Switched to SunCam");
    }

    public void ShowMoonView()
    {
        SetActiveCamera(moonCam);
        Debug.Log("Switched to MoonCam");
    }

    public void ShowDefaultView()
    {
        SetActiveCamera(defaultCam);
        Debug.Log("Switched to DefaultCam");
    }

    private void SetActiveCamera(Camera activeCamera)
    {
        // Disable all cameras first
        earthCam.enabled = false;
        sunCam.enabled = false;
        moonCam.enabled = false;
        defaultCam.enabled = false;

        // Enable only the selected camera
        activeCamera.enabled = true;
    }
}
