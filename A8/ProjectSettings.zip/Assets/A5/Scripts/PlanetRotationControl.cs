using UnityEngine;
using UnityEngine.UI;

public class PlanetRotationControl : MonoBehaviour
{
    public Slider rotationSlider;  // Assign this in the Inspector
    public float rotationSpeed = 10f;

    void Update()
    {
        // Set rotation speed based on the slider value
        rotationSpeed = rotationSlider.value;
        Rotate();
    }

    private void Rotate()
    {
        // Rotate the object around the Y-axis (up) based on the speed
        transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
    }
}
