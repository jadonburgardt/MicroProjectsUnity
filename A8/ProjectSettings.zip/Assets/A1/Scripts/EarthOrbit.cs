using UnityEngine;

public class EarthOrbit : MonoBehaviour
{
    public Transform sun;
    public float orbitSpeed = 20f;
    public float rotationSpeed = 30f;

    void Update()
    {
        // Orbit around the Sun
        transform.RotateAround(sun.position, Vector3.up, orbitSpeed * Time.deltaTime);

        // Rotate on its axis
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
    }
}
