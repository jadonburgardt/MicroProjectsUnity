using UnityEngine;

public class MoonOrbit : MonoBehaviour
{
    public Transform earth;
    [Range(125f, 500f)] public float orbitSpeed = 125f;  // Default range between 125 and 500
    public float rotationSpeed = 10f;

    void Update()
    {
        // Clamp orbit speed to ensure it stays above the minimum value
        orbitSpeed = Mathf.Max(orbitSpeed, 125f);

        // Orbit around the Earth
        transform.RotateAround(earth.position, Vector3.up, orbitSpeed * Time.deltaTime);

        // Rotate on its axis
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);
    }
}
