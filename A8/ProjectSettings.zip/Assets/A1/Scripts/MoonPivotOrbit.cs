using UnityEngine;

public class MoonPivotOrbit : MonoBehaviour
{
    public float orbitSpeed = 50f;  // Speed of orbit

    void Update()
    {
        // Rotate the pivot to make the Moon orbit the Earth
        transform.Rotate(Vector3.up, orbitSpeed * Time.deltaTime);
    }
}
