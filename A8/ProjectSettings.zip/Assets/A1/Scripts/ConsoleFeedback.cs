using UnityEngine;

public class ConsoleFeedback : MonoBehaviour
{
    void Start()
    {
        Debug.Log("Game Started: Rotation and orbits initialized.");
    }
}
