

//using UnityEngine;
//using UnityEngine.UI;

//public class BallControl : MonoBehaviour
//{
//    public Slider forceSlider, spinSlider, aimSlider;
//    public Button throwButton;
//    public GameObject bowlingBall;

//    private Rigidbody ballRigidbody;
//    private bool canThrow = true;

//    void Start()
//    {
//        ballRigidbody = bowlingBall.GetComponent<Rigidbody>();
//        throwButton.onClick.AddListener(ThrowBall);
//    }

//    void ThrowBall()
//    {
//        if (canThrow)
//        {
//            canThrow = false;

//            float force = forceSlider.value * 450f;
//            Vector3 direction = bowlingBall.transform.forward;
//            ballRigidbody.AddForce(direction * force, ForceMode.Impulse);

//            Invoke("ApplySpin", 0.5f);
//            Invoke("ResetThrow", 5f);

//            FindObjectOfType<ResetManager>().StartResetTimer();
//            Invoke("CheckKnockedPins", 5f);
//        }
//    }

//    void ApplySpin()
//    {
//        Vector3 spinForce = bowlingBall.transform.right * spinSlider.value;
//        ballRigidbody.AddForce(spinForce, ForceMode.Impulse);
//    }

//    void ResetThrow()
//    {
//        canThrow = true;
//    }

//    void CheckKnockedPins()
//    {
//        int knockedDown = FindObjectOfType<PinManager>().GetKnockedPins();
//        int totalPins = FindObjectOfType<PinManager>().GetTotalPinCount();
//        int standingPins = totalPins - knockedDown;

//        Debug.Log($"Knocked down pins: {knockedDown}, Standing pins: {standingPins}");
//        FindObjectOfType<BowlingScoreManager>().RecordRoll(knockedDown);
//    }
//}






using UnityEngine;
using UnityEngine.UI;

public class BallControl : MonoBehaviour
{
    public Slider forceSlider, spinSlider, aimSlider;  // Sliders for user input
    public Button throwButton;
    public GameObject bowlingBall;

    public float maxAimAngle = 30f;       // Max aim angle adjustment
    public float maxSpinStrength = 10f;   // Max spin strength
    public float spinDelay = 0.5f;        // Delay before spin starts
    public float spinDuration = 2f;       // Duration for spin effect

    private Rigidbody ballRigidbody;
    private Vector3 originalBallPosition; // Store original ball position
    private bool canThrow = true;

    void Start()
    {
        ballRigidbody = bowlingBall.GetComponent<Rigidbody>();
        originalBallPosition = bowlingBall.transform.position;

        throwButton.onClick.AddListener(ThrowBall);

        // Initialize sliders to their default states
        ResetSliders();
    }

    void ThrowBall()
    {
        if (canThrow)
        {
            canThrow = false;

            float force = forceSlider.value * 450f;

            // Adjust direction using aim slider
            float aimOffset = aimSlider.value * maxAimAngle;
            Vector3 direction = Quaternion.Euler(0, aimOffset, 0) * bowlingBall.transform.forward;

            ballRigidbody.AddForce(direction * force, ForceMode.Impulse);

            Invoke(nameof(ApplySpin), spinDelay);  // Delay spin
            Invoke(nameof(ResetThrow), 5f);        // Reset throw

            FindObjectOfType<ResetManager>().StartResetTimer();
            Invoke(nameof(CheckKnockedPins), 5f);
        }
    }

    void ApplySpin()
    {
        float spinValue = spinSlider.value * maxSpinStrength;
        Vector3 spinForce = bowlingBall.transform.right * spinValue;

        ballRigidbody.AddForce(spinForce, ForceMode.Impulse);
        Invoke(nameof(StopSpin), spinDuration);  // Stop spin after duration
    }

    void StopSpin()
    {
        ballRigidbody.angularVelocity = Vector3.zero;
    }

    void ResetThrow()
    {
        canThrow = true;
    }

    public void ResetSliders()
    {
        forceSlider.value = forceSlider.minValue;  // Reset force slider to minimum
        spinSlider.value = (spinSlider.minValue + spinSlider.maxValue) / 2;  // Reset spin slider to middle
        aimSlider.value = (aimSlider.minValue + aimSlider.maxValue) / 2;    // Reset aim slider to middle
    }

    public void SetRandomBallPosition()
    {
        float randomX = Random.Range(-0.3f, 0.3f);  // Random X offset
        Vector3 newPosition = new Vector3(originalBallPosition.x + randomX, originalBallPosition.y, originalBallPosition.z);
        bowlingBall.transform.position = newPosition;
        bowlingBall.transform.rotation = Quaternion.identity;

        // Reset ball physics
        ballRigidbody.velocity = Vector3.zero;
        ballRigidbody.angularVelocity = Vector3.zero;
    }

    void CheckKnockedPins()
    {
        int knockedDown = FindObjectOfType<PinManager>().GetKnockedPins();
        Debug.Log($"Knocked down pins: {knockedDown}");
        FindObjectOfType<BowlingScoreManager>().RecordRoll(knockedDown);
    }
}
