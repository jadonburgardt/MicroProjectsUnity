

//using TMPro;
//using UnityEngine;
//using UnityEngine.UI;  // Include for managing UI elements
//using System.Collections.Generic;

//public class BowlingScoreManager : MonoBehaviour
//{
//    public TMP_Text cumulativeTotal;  // Final cumulative score UI element
//    public TMP_Text[] frameRolls = new TMP_Text[21];  // Display each roll
//    public Button throwButton;  // Reference to the Throw Button

//    private List<Frame> frames = new List<Frame>();  // Store the frames
//    private int currentFrameIndex = 0;  // Track the current frame index
//    private bool isSecondRoll = false;  // Track if we�re on the second roll
//    private bool isExtraRollAllowed = false;  // Track if the 11th frame is allowed

//    void Start()
//    {
//        // Initialize 10 frames + 1 extra for the 11th frame (if applicable)
//        for (int i = 0; i < 11; i++) frames.Add(new Frame());
//    }

//    public void RecordRoll(int pinsKnockedDown)
//    {
//        if (currentFrameIndex >= 11) return;  // Stop rolling after the game ends

//        var frame = frames[currentFrameIndex];
//        frame.AddRoll(pinsKnockedDown);  // Record the roll

//        UpdateRollUI(currentFrameIndex, pinsKnockedDown);  // Update UI

//        // Handle 10th frame logic
//        if (currentFrameIndex == 9)
//        {
//            HandleTenthFrame(pinsKnockedDown);
//        }
//        else if (currentFrameIndex == 10)  // Handle the 11th frame
//        {
//            EndGame();  // End the game after the 11th frame roll
//        }
//        else if (frame.IsStrike() && !isSecondRoll)  // Handle strike
//        {
//            currentFrameIndex++;  // Move to the next frame
//        }
//        else if (isSecondRoll)  // Move to the next frame after the second roll
//        {
//            currentFrameIndex++;
//            isSecondRoll = false;
//        }
//        else  // Prepare for the second roll
//        {
//            isSecondRoll = true;
//        }

//        UpdateCumulativeScore();  // Update the scoreboard
//    }

//    private void HandleTenthFrame(int pinsKnockedDown)
//    {
//        var frame = frames[9];

//        if (!isSecondRoll)  // First roll of the 10th frame
//        {
//            isSecondRoll = true;

//            if (frame.IsStrike())  // Log strike
//            {
//                Debug.Log("First roll of 10th frame is a strike.");
//            }
//        }
//        else  // Second roll of the 10th frame
//        {
//            if (frame.IsSpare() || frame.IsStrike())  // Allow extra roll
//            {
//                isExtraRollAllowed = true;
//                Debug.Log("Spare or strike on second roll allows an extra roll.");
//                currentFrameIndex++;
//            }
//            else  // No extra roll allowed
//            {
//                Debug.Log("No extra roll allowed.");
//                HideThrowButton();  // Hide the Throw Button
//                EndGame();  // End the game
//            }

//            isSecondRoll = false;
//        }
//    }

//    private void HideThrowButton()
//    {
//        if (throwButton != null)
//        {
//            throwButton.gameObject.SetActive(false);  // Hide the button
//            Debug.Log("Throw button hidden.");
//        }
//    }

//    private void EndGame()
//    {
//        HideThrowButton();  // Ensure the button is hidden at the end of the game
//        Debug.Log("Game Over!");
//    }

//    private void UpdateRollUI(int frameIndex, int pinsKnockedDown)
//    {
//        int rollIndex = frameIndex * 2 + (isSecondRoll ? 1 : 0);

//        // Display strike as 'X'
//        if (frameIndex == 9 && pinsKnockedDown == 10)
//        {
//            frameRolls[rollIndex].text = "X";
//        }
//        else if (pinsKnockedDown == 10 && !isSecondRoll)
//        {
//            frameRolls[rollIndex].text = "X";
//        }
//        else if (isSecondRoll && frames[frameIndex].IsSpare())
//        {
//            frameRolls[rollIndex].text = "/";
//        }
//        else if (isSecondRoll)
//        {
//            int secondRollValue = pinsKnockedDown - (frames[frameIndex].Roll1 ?? 0);
//            frameRolls[rollIndex].text = Mathf.Max(secondRollValue, 0).ToString();
//        }
//        else if (pinsKnockedDown == 0)
//        {
//            frameRolls[rollIndex].text = "0";
//        }
//        else
//        {
//            frameRolls[rollIndex].text = pinsKnockedDown.ToString();
//        }
//    }

//    private void UpdateCumulativeScore()
//    {
//        int totalScore = 0;

//        for (int i = 0; i < 10; i++)
//        {
//            totalScore += frames[i].GetScore(frames, i);

//            if (i == 9)
//            {
//                if (frames[i].Roll2.HasValue) totalScore += frames[i].Roll2.Value;
//                if (frames[i].Roll3.HasValue) totalScore += frames[i].Roll3.Value;
//            }
//        }

//        cumulativeTotal.text = totalScore.ToString();
//    }

//    public class Frame
//    {
//        public int? Roll1 { get; private set; }
//        public int? Roll2 { get; private set; }
//        public int? Roll3 { get; private set; }

//        public void AddRoll(int pins)
//        {
//            if (!Roll1.HasValue) Roll1 = pins;
//            else if (!Roll2.HasValue) Roll2 = pins;
//            else Roll3 = pins;
//        }

//        public bool IsStrike() => Roll1 == 10;
//        public bool IsSpare() => Roll1.HasValue && Roll2.HasValue && (Roll1 + Roll2 == 10);

//        public int GetScore(List<Frame> frames, int index)
//        {
//            int score = (Roll1 ?? 0) + (Roll2 ?? 0) + (Roll3 ?? 0);

//            if (IsStrike() && index < 9) score += GetNextTwoRolls(frames, index);
//            else if (IsSpare() && index < 9) score += GetNextRoll(frames, index);

//            return score;
//        }

//        private int GetNextRoll(List<Frame> frames, int index)
//        {
//            return index + 1 < frames.Count ? frames[index + 1].Roll1 ?? 0 : 0;
//        }

//        private int GetNextTwoRolls(List<Frame> frames, int index)
//        {
//            if (index + 1 >= frames.Count) return 0;

//            var nextFrame = frames[index + 1];

//            if (nextFrame.IsStrike() && index + 2 < frames.Count)
//                return 10 + (frames[index + 2].Roll1 ?? 0);

//            return (nextFrame.Roll1 ?? 0) + (nextFrame.Roll2 ?? 0);
//        }
//    }
//}


//using TMPro;
//using UnityEngine;
//using UnityEngine.UI;  // For managing UI elements
//using System.Collections.Generic;

//public class BowlingScoreManager : MonoBehaviour
//{
//    public TMP_Text cumulativeTotal;  // Final cumulative score UI element
//    public TMP_Text[] frameRolls = new TMP_Text[21];  // Display each roll
//    public Button throwButton;  // Reference to the UI Throw Button
//    public Button restartButton;

//    private List<Frame> frames = new List<Frame>();  // Store the frames
//    private int currentFrameIndex = 0;  // Track the current frame index
//    private bool isSecondRoll = false;  // Track if we�re on the second roll
//    private bool isGameOver = false;  // Track if the game is over

//    void Start()
//    {
//        // Initialize 10 frames + 1 extra for the 11th frame (if applicable)
//        for (int i = 0; i < 11; i++) frames.Add(new Frame());
//    }

//    public void RecordRoll(int pinsKnockedDown)
//    {
//        if (isGameOver) return;  // Stop if the game is over

//        var frame = frames[currentFrameIndex];
//        frame.AddRoll(pinsKnockedDown);  // Record the roll

//        UpdateRollUI(currentFrameIndex, pinsKnockedDown);  // Update UI

//        if (currentFrameIndex == 9)  // Handle 10th frame logic
//        {
//            HandleTenthFrame(pinsKnockedDown);
//        }
//        else if (currentFrameIndex == 10)  // Handle 11th frame
//        {
//            EndGame();  // End the game after the 11th frame
//        }
//        else if (frame.IsStrike() && !isSecondRoll)  // Move to next frame after a strike
//        {
//            currentFrameIndex++;
//        }
//        else if (isSecondRoll)  // Move to the next frame after second roll
//        {
//            currentFrameIndex++;
//            isSecondRoll = false;
//        }
//        else  // Prepare for second roll
//        {
//            isSecondRoll = true;
//        }

//        UpdateCumulativeScore();  // Update the scoreboard
//    }

//    private void HandleTenthFrame(int pinsKnockedDown)
//    {
//        var frame = frames[9];

//        if (!isSecondRoll)  // First roll of the 10th frame
//        {
//            isSecondRoll = true;
//            if (frame.IsStrike())
//            {
//                Debug.Log("First roll of 10th frame is a strike.");
//            }
//        }
//        else  // Second roll of the 10th frame
//        {
//            if (frame.IsSpare() || frame.IsStrike())  // Allow extra roll
//            {
//                Debug.Log("Spare or strike on second roll allows an extra roll.");
//                currentFrameIndex++;
//            }
//            else  // No extra roll allowed
//            {
//                Debug.Log("No extra roll allowed.");
//                HideThrowButton();  // Hide the button
//                EndGame();  // End the game
//            }

//            isSecondRoll = false;
//        }
//    }

//    private void HideThrowButton()
//    {
//        if (throwButton != null)
//        {
//            throwButton.gameObject.SetActive(false);  // Hide the button
//            Debug.Log("Throw button hidden.");
//        }
//        else
//        {
//            Debug.LogWarning("Throw Button reference is null. Please assign it in the Inspector.");
//        }
//    }

//    private void EndGame()
//    {
//        HideThrowButton();  // Ensure button is hidden at the end
//        Debug.Log("Game Over!");
//    }

//    private void UpdateRollUI(int frameIndex, int pinsKnockedDown)
//    {
//        int rollIndex = frameIndex * 2 + (isSecondRoll ? 1 : 0);

//        var frame = frames[frameIndex];  // Access the current frame

//        if (frameIndex == 9 && pinsKnockedDown == 10)
//        {
//            frameRolls[rollIndex].text = "X";  // Strike in 10th frame
//        }
//        else if (pinsKnockedDown == 10 && !isSecondRoll)
//        {
//            frameRolls[rollIndex].text = "X";  // Regular strike
//        }
//        else if (isSecondRoll && frame.IsSpare())
//        {
//            frameRolls[rollIndex].text = "/";  // Spare
//        }
//        else if (isSecondRoll)
//        {
//            int secondRollValue = Mathf.Max((frame.Roll2 ?? 0) - (frame.Roll1 ?? 0), 0);
//            frameRolls[rollIndex].text = secondRollValue.ToString();
//        }
//        else if (pinsKnockedDown == 0)
//        {
//            frameRolls[rollIndex].text = "0";  // Display zero
//        }
//        else
//        {
//            frameRolls[rollIndex].text = pinsKnockedDown.ToString();
//        }
//    }


//    private void UpdateCumulativeScore()
//    {
//        int totalScore = 0;
//        int strikeCount = 0;  // Track the total number of strikes

//        // Loop through the first 10 frames and calculate scores
//        for (int i = 0; i < 10; i++)
//        {
//            var frame = frames[i];

//            // Add the frame's score to the total
//            totalScore += frame.GetScore(frames, i);

//            // Count the strikes
//            if (frame.IsStrike()) strikeCount++;

//            // Handle extra rolls in the 10th frame
//            if (i == 9)
//            {
//                if (frame.Roll2.HasValue && frame.Roll2.Value == 10) strikeCount++;  // Bonus roll strike
//                if (frame.Roll3.HasValue && frame.Roll3.Value == 10) strikeCount++;  // Extra bonus roll strike

//                // Add extra rolls to the total score
//                if (frame.Roll2.HasValue) totalScore += frame.Roll2.Value;
//                if (frame.Roll3.HasValue) totalScore += frame.Roll3.Value;
//            }
//        }

//        // Check if there are exactly 12 strikes for a perfect game
//        if (strikeCount == 12)
//        {
//            totalScore = 300;  // Hardcode the score to 300 for a perfect game
//            Debug.Log("Perfect game! Score set to 300.");
//        }

//        cumulativeTotal.text = totalScore.ToString();  // Update the UI
//    }



//    public class Frame
//    {
//        public int? Roll1 { get; private set; }
//        public int? Roll2 { get; private set; }
//        public int? Roll3 { get; private set; }

//        public void AddRoll(int pins)
//        {
//            if (!Roll1.HasValue) Roll1 = pins;
//            else if (!Roll2.HasValue) Roll2 = pins;
//            else Roll3 = pins;
//        }

//        public bool IsStrike() => Roll1 == 10;
//        public bool IsSpare() => Roll1.HasValue && Roll2.HasValue && (Roll1 + Roll2 == 10);

//        public int GetScore(List<Frame> frames, int index)
//        {
//            int firstRoll = Roll1 ?? 0;
//            int secondRoll = Roll2 ?? 0;

//            // Use the raw second roll value, no subtraction logic here
//            int score = firstRoll + secondRoll;

//            // Handle bonus for strikes (only for frames 1-9)
//            if (IsStrike() && index < 9)
//            {
//                score += GetNextTwoRolls(frames, index);
//            }
//            // Handle bonus for spares (only for frames 1-9)
//            else if (IsSpare() && index < 9)
//            {
//                score += GetNextRoll(frames, index);
//            }

//            return score;
//        }

//        private int GetNextRoll(List<Frame> frames, int index)
//        {
//            return index + 1 < frames.Count ? frames[index + 1].Roll1 ?? 0 : 0;
//        }

//        private int GetNextTwoRolls(List<Frame> frames, int index)
//        {
//            if (index + 1 >= frames.Count) return 0;

//            var nextFrame = frames[index + 1];
//            if (nextFrame.IsStrike() && index + 2 < frames.Count)
//            {
//                return 10 + (frames[index + 2].Roll1 ?? 0);
//            }

//            return (nextFrame.Roll1 ?? 0) + (nextFrame.Roll2 ?? 0);
//        }


//    }
//}



using TMPro;
using UnityEngine;
using UnityEngine.UI;  // For managing UI elements
using UnityEngine.SceneManagement;  // For reloading the scene
using System.Collections.Generic;

public class BowlingScoreManager : MonoBehaviour
{
    public TMP_Text cumulativeTotal;  // Final cumulative score UI element
    public TMP_Text[] frameRolls = new TMP_Text[21];  // Display each roll
    public Button throwButton;  // Reference to the Throw Button
    public Button restartButton;  // Reference to the Restart Button

    private List<Frame> frames = new List<Frame>();  // Store the frames
    private int currentFrameIndex = 0;  // Track the current frame index
    private bool isSecondRoll = false;  // Track if we�re on the second roll
    private bool isGameOver = false;  // Track if the game is over

    void Start()
    {
        // Initialize 10 frames + 1 extra frame if needed
        for (int i = 0; i < 11; i++)
            frames.Add(new Frame());

        // Link the restart button to the restart function
        restartButton.onClick.AddListener(RestartGame);
    }

    public void RecordRoll(int pinsKnockedDown)
    {
        if (isGameOver) return;  // Stop recording rolls if the game is over

        var frame = frames[currentFrameIndex];
        frame.AddRoll(pinsKnockedDown);  // Record the roll

        UpdateRollUI(currentFrameIndex, pinsKnockedDown);  // Update the roll display

        if (currentFrameIndex == 9)
        {
            HandleTenthFrame(pinsKnockedDown);  // Handle 10th frame logic
        }
        else if (currentFrameIndex == 10)
        {
            EndGame();  // End the game after the bonus frame
        }
        else if (frame.IsStrike() && !isSecondRoll)
        {
            currentFrameIndex++;  // Move to the next frame after a strike
        }
        else if (isSecondRoll)
        {
            currentFrameIndex++;
            isSecondRoll = false;  // Reset the second roll flag
        }
        else
        {
            isSecondRoll = true;  // Prepare for the second roll
        }

        UpdateCumulativeScore();  // Update the scoreboard
    }

    private void HandleTenthFrame(int pinsKnockedDown)
    {
        var frame = frames[9];

        if (!isSecondRoll)  // First roll of the 10th frame
        {
            isSecondRoll = true;

            if (frame.IsStrike())
                Debug.Log("First roll of 10th frame is a strike.");
        }
        else  // Second roll of the 10th frame
        {
            if (frame.IsSpare() || frame.IsStrike())
            {
                Debug.Log("Spare or strike on second roll allows an extra roll.");
                currentFrameIndex++;
            }
            else
            {
                Debug.Log("No extra roll allowed.");
                EndGame();  // End the game if no extra roll is allowed
            }
            isSecondRoll = false;
        }
    }

    private void UpdateRollUI(int frameIndex, int pinsKnockedDown)
    {
        int rollIndex = frameIndex * 2 + (isSecondRoll ? 1 : 0);
        var frame = frames[frameIndex];

        if (frameIndex == 9 && pinsKnockedDown == 10)
        {
            frameRolls[rollIndex].text = "X";  // Strike in 10th frame
        }
        else if (pinsKnockedDown == 10 && !isSecondRoll)
        {
            frameRolls[rollIndex].text = "X";  // Regular strike
        }
        else if (isSecondRoll && frame.IsSpare())
        {
            frameRolls[rollIndex].text = "/";  // Spare
        }
        else if (isSecondRoll)
        {
            int secondRollValue = Mathf.Max((frame.Roll2 ?? 0) - (frame.Roll1 ?? 0), 0);
            frameRolls[rollIndex].text = secondRollValue.ToString();
        }
        else if (pinsKnockedDown == 0)
        {
            frameRolls[rollIndex].text = "0";  // Display zero
        }
        else
        {
            frameRolls[rollIndex].text = pinsKnockedDown.ToString();
        }
    }

    private void UpdateCumulativeScore()
    {
        int totalScore = 0;
        int strikeCount = 0;

        for (int i = 0; i < 10; i++)
        {
            var frame = frames[i];
            totalScore += frame.GetScore(frames, i);

            if (frame.IsStrike()) strikeCount++;

            if (i == 9)
            {
                if (frame.Roll2.HasValue && frame.Roll2.Value == 10) strikeCount++;
                if (frame.Roll3.HasValue && frame.Roll3.Value == 10) strikeCount++;
            }
        }

        if (strikeCount == 12)
        {
            totalScore = 300;
            Debug.Log("Perfect game! Score set to 300.");
        }

        cumulativeTotal.text = totalScore.ToString();
    }

    private void EndGame()
    {
        HideThrowButton();  // Hide the throw button at the end of the game
        isGameOver = true;
        Debug.Log("Game Over!");
    }

    private void HideThrowButton()
    {
        if (throwButton != null)
        {
            throwButton.gameObject.SetActive(false);
            Debug.Log("Throw button hidden.");
        }
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);  // Reload the current scene
        Debug.Log("Game restarted!");
    }

    public class Frame
    {
        public int? Roll1 { get; private set; }
        public int? Roll2 { get; private set; }
        public int? Roll3 { get; private set; }

        public void AddRoll(int pins)
        {
            if (!Roll1.HasValue) Roll1 = pins;
            else if (!Roll2.HasValue) Roll2 = pins;
            else Roll3 = pins;
        }

        public bool IsStrike() => Roll1 == 10;
        public bool IsSpare() => Roll1.HasValue && Roll2.HasValue && (Roll1 + Roll2 == 10);

        public int GetScore(List<Frame> frames, int index)
        {
            int firstRoll = Roll1 ?? 0;
            int secondRollContribution = Mathf.Max((Roll2 ?? 0) - firstRoll, 0);
            int score = firstRoll + secondRollContribution;

            if (index == 9) score += Roll3 ?? 0;

            if (IsStrike() && index < 9) score += GetNextTwoRolls(frames, index);
            else if (IsSpare() && index < 9) score += GetNextRoll(frames, index);

            return score;
        }

        private int GetNextRoll(List<Frame> frames, int index)
        {
            return index + 1 < frames.Count ? frames[index + 1].Roll1 ?? 0 : 0;
        }

        private int GetNextTwoRolls(List<Frame> frames, int index)
        {
            if (index + 1 >= frames.Count) return 0;
            var nextFrame = frames[index + 1];
            if (nextFrame.IsStrike() && index + 2 < frames.Count)
                return 10 + (frames[index + 2].Roll1 ?? 0);
            return (nextFrame.Roll1 ?? 0) + (nextFrame.Roll2 ?? 0);
        }
    }
}
