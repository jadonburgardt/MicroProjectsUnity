
//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class ResetManager : MonoBehaviour
//{
//    public GameObject ball;
//    public GameObject pinManager;  // Reference to the PinManager object
//    private Vector3 ballStartPosition;
//    private bool isResetting = false;
//    private int rollInCurrentFrame = 1;  // Track the roll within the current frame

//    void Start()
//    {
//        ballStartPosition = ball.transform.position;
//    }

//    public void StartResetTimer()
//    {
//        Debug.Log($"Reset timer started for roll {rollInCurrentFrame}. Reset in 5 seconds...");
//        Invoke(nameof(ResetPinsAndBall), 5f);  // Reset after 5 seconds
//    }

//    void ResetPinsAndBall()
//    {
//        if (!isResetting)
//        {
//            Debug.Log($"Resetting after roll {rollInCurrentFrame}...");
//            StartCoroutine(ResetPinsAndBallCoroutine());
//        }
//    }

//    IEnumerator ResetPinsAndBallCoroutine()
//    {
//        isResetting = true;

//        // Reset the ball position first to avoid interference
//        ResetBall();

//        if (IsFrameComplete())  // Full reset only if the frame is complete
//        {
//            ClearAllPins();  // Remove old pins
//            yield return new WaitForEndOfFrame();  // Ensure old pins are fully destroyed
//            SpawnNewPins();  // Spawn a new set of pins for the next frame
//            rollInCurrentFrame = 1;  // Reset to the first roll of the new frame
//        }
//        else  // Partial reset for the second roll in the same frame
//        {
//            DisableKnockedPins();  // Disable only knocked-down pins
//            rollInCurrentFrame++;  // Move to the second roll of the same frame
//        }

//        isResetting = false;
//        yield return null;
//    }

//    void ResetBall()
//    {
//        if (ball != null)
//        {
//            ball.transform.position = ballStartPosition;
//            ball.transform.rotation = Quaternion.identity;

//            var rb = ball.GetComponent<Rigidbody>();
//            if (rb != null)
//            {
//                rb.velocity = Vector3.zero;
//                rb.angularVelocity = Vector3.zero;
//            }
//        }
//        else
//        {
//            Debug.LogWarning("Ball reference is null!");
//        }
//    }

//    void ClearAllPins()
//    {
//        GameObject[] allPins = GameObject.FindGameObjectsWithTag("Pin");
//        foreach (GameObject pin in allPins)
//        {
//            if (pin != null)
//            {
//                Destroy(pin);  // Destroy all old pins
//            }
//        }
//    }

//    void DisableKnockedPins()
//    {
//        List<GameObject> standingPins = pinManager.GetComponent<PinManager>().GetStandingPins();

//        GameObject[] allPins = GameObject.FindGameObjectsWithTag("Pin");
//        foreach (GameObject pin in allPins)
//        {
//            if (pin != null && !standingPins.Contains(pin))
//            {
//                pin.SetActive(false);  // Disable knocked-down pins only
//            }
//        }
//    }

//    void SpawnNewPins()
//    {
//        pinManager.GetComponent<PinManager>().Start();  // Spawn a new set of pins
//    }

//    bool IsFrameComplete()
//    {
//        // A frame is complete if:
//        // 1. This is the second roll in the frame
//        // 2. Or the first roll was a strike (all pins down)
//        bool isStrike = FindObjectOfType<PinManager>().GetKnockedPins() == 10;
//        return rollInCurrentFrame == 2 || isStrike;
//    }
//}


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetManager : MonoBehaviour
{
    public GameObject ball;
    public GameObject pinManager;  // Reference to PinManager

    private BallControl ballControl;
    private bool isResetting = false;
    private Vector3 ballStartPosition;
    private int rollInCurrentFrame = 1;  // Track current roll

    void Start()
    {
        ballStartPosition = ball.transform.position;
        ballControl = ball.GetComponent<BallControl>();
    }

    public void StartResetTimer()
    {
        Debug.Log($"Reset timer started for roll {rollInCurrentFrame}. Reset in 5 seconds...");
        Invoke(nameof(ResetPinsAndBall), 5f);
    }

    void ResetPinsAndBall()
    {
        if (!isResetting)
        {
            Debug.Log($"Resetting after roll {rollInCurrentFrame}...");
            StartCoroutine(ResetPinsAndBallCoroutine());
        }
    }

    IEnumerator ResetPinsAndBallCoroutine()
    {
        isResetting = true;

        // Set a new random ball position
        ballControl.SetRandomBallPosition();

        // Reset sliders to default values
        ballControl.ResetSliders();

        if (IsFrameComplete())
        {
            ClearAllPins();
            yield return new WaitForEndOfFrame();
            SpawnNewPins();
            rollInCurrentFrame = 1;
        }
        else
        {
            DisableKnockedPins();
            rollInCurrentFrame++;
        }

        isResetting = false;
    }

    void ClearAllPins()
    {
        GameObject[] allPins = GameObject.FindGameObjectsWithTag("Pin");
        foreach (GameObject pin in allPins)
        {
            Destroy(pin);
        }
    }

    void DisableKnockedPins()
    {
        List<GameObject> standingPins = pinManager.GetComponent<PinManager>().GetStandingPins();
        GameObject[] allPins = GameObject.FindGameObjectsWithTag("Pin");

        foreach (GameObject pin in allPins)
        {
            if (!standingPins.Contains(pin))
            {
                pin.SetActive(false);
            }
        }
    }

    void SpawnNewPins()
    {
        pinManager.GetComponent<PinManager>().Start();
    }

    bool IsFrameComplete()
    {
        bool isStrike = FindObjectOfType<PinManager>().GetKnockedPins() == 10;
        return rollInCurrentFrame == 2 || isStrike;
    }
}
