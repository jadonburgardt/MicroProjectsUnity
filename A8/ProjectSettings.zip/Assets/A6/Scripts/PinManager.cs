
//using System.Collections.Generic;
//using UnityEngine;

//public class PinManager : MonoBehaviour
//{
//    public GameObject pinPrefab;  // Reference to the pin prefab
//    public int rows = 4;  // Number of rows of pins
//    public Vector3 startPosition;  // Starting position for pin placement

//    // Keep initial pin positions private and expose them through a public property
//    private Dictionary<GameObject, Vector3> initialPinPositions = new Dictionary<GameObject, Vector3>();

//    // Public read-only property to expose initial pin positions
//    public Dictionary<GameObject, Vector3> InitialPinPositions => initialPinPositions;

//    public void Start()
//    {
//        initialPinPositions.Clear();  // Clear old references before initializing new pins

//        float spacing = 1f;  // Space between pins

//        for (int row = 0; row < rows; row++)
//        {
//            for (int i = 0; i <= row; i++)
//            {
//                Vector3 position = startPosition + new Vector3(i * spacing - row * spacing / 2, 0, row * spacing);

//                GameObject pinInstance = Instantiate(pinPrefab, position, Quaternion.identity);
//                pinInstance.tag = "Pin";

//                // Store the initial position of the pin
//                initialPinPositions[pinInstance] = pinInstance.transform.position;
//            }
//        }
//    }

//    public int GetTotalPinCount()
//    {
//        return initialPinPositions.Count;
//    }


//    public List<GameObject> GetStandingPins()
//    {
//        List<GameObject> standingPins = new List<GameObject>();

//        foreach (var entry in initialPinPositions)
//        {
//            GameObject pin = entry.Key;
//            Vector3 initialPosition = entry.Value;

//            bool isMoved = Vector3.Distance(pin.transform.position, initialPosition) > 0.5f;
//            Rigidbody pinRigidbody = pin.GetComponent<Rigidbody>();
//            bool isTilted = pin.transform.up.y < 0.5f;

//            // If the pin is neither moved nor tilted, it is standing
//            if (!(isMoved || (pinRigidbody != null && isTilted)))
//            {
//                standingPins.Add(pin);
//            }
//        }

//        return standingPins;
//    }

//    public int GetKnockedPins()
//    {
//        int knockedDown = 0;

//        foreach (var entry in initialPinPositions)
//        {
//            GameObject pin = entry.Key;
//            Vector3 initialPosition = entry.Value;

//            bool isMoved = Vector3.Distance(pin.transform.position, initialPosition) > 0.5f;
//            Rigidbody pinRigidbody = pin.GetComponent<Rigidbody>();
//            bool isTilted = pin.transform.up.y < 0.5f;

//            if (isMoved || (pinRigidbody != null && isTilted))
//            {
//                knockedDown++;
//            }
//        }

//        Debug.Log($"Knocked down pins (accurate): {knockedDown}");
//        return knockedDown;
//    }
//}





using System.Collections.Generic;
using UnityEngine;

public class PinManager : MonoBehaviour
{
    public GameObject pinPrefab;  // Reference to the pin prefab
    public int rows = 4;  // Number of rows of pins
    public Vector3 startPosition;  // Starting position for pin placement

    // Keep initial pin positions private and expose them through a public property
    private Dictionary<GameObject, Vector3> initialPinPositions = new Dictionary<GameObject, Vector3>();

    // Public read-only property to expose initial pin positions
    public Dictionary<GameObject, Vector3> InitialPinPositions => initialPinPositions;

    public void Start()
    {
        initialPinPositions.Clear();  // Clear old references before initializing new pins

        float spacing = 1f;  // Space between pins

        for (int row = 0; row < rows; row++)
        {
            for (int i = 0; i <= row; i++)
            {
                Vector3 position = startPosition + new Vector3(i * spacing - row * spacing / 2, 0, row * spacing);

                GameObject pinInstance = Instantiate(pinPrefab, position, Quaternion.identity);
                pinInstance.tag = "Pin";

                // Store the initial position of the pin
                initialPinPositions[pinInstance] = pinInstance.transform.position;
            }
        }
    }

    public int GetTotalPinCount()
    {
        return initialPinPositions.Count;
    }


    public List<GameObject> GetStandingPins()
    {
        List<GameObject> standingPins = new List<GameObject>();

        foreach (var entry in initialPinPositions)
        {
            GameObject pin = entry.Key;
            Vector3 initialPosition = entry.Value;

            bool isMoved = Vector3.Distance(pin.transform.position, initialPosition) > 0.5f;
            Rigidbody pinRigidbody = pin.GetComponent<Rigidbody>();
            bool isTilted = pin.transform.up.y < 0.5f;

            // If the pin is neither moved nor tilted, it is standing
            if (!(isMoved || (pinRigidbody != null && isTilted)))
            {
                standingPins.Add(pin);
            }
        }

        return standingPins;
    }

    public int GetKnockedPins()
    {
        int knockedDown = 0;

        foreach (var entry in initialPinPositions)
        {
            GameObject pin = entry.Key;
            Vector3 initialPosition = entry.Value;

            bool isMoved = Vector3.Distance(pin.transform.position, initialPosition) > 0.5f;
            Rigidbody pinRigidbody = pin.GetComponent<Rigidbody>();
            bool isTilted = pin.transform.up.y < 0.5f;

            if (isMoved || (pinRigidbody != null && isTilted))
            {
                knockedDown++;
            }
        }

        Debug.Log($"Knocked down pins (accurate): {knockedDown}");
        return knockedDown;
    }
}


