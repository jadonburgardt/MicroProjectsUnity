using UnityEngine;

public class CubeBounce : MonoBehaviour
{
    public float bounceHeight = 2f;    // Maximum height of the bounce
    public float speed = 2f;           // Speed of the bounce

    private Vector3 initialPosition;   // Store the starting position

    void Start()
    {
        // Store the initial position of the cube
        initialPosition = transform.position;
    }

    void Update()
    {
        // Calculate the new Y position using a sine wave
        float newY = Mathf.Abs(Mathf.Sin(Time.time * speed)) * bounceHeight;

        // Apply the new position to the cube
        transform.position = new Vector3(initialPosition.x, initialPosition.y + newY, initialPosition.z);

        Debug.Log($"{gameObject.name} is at height: {transform.position.y}");


    }
}
